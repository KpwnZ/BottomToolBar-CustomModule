#import <UIKit/UIKit.h>

@interface BTBCustomModuleViewController : UIViewController
@property (nonatomic, retain) UIView *containerView;
- (CGFloat)preferHeight;
- (instancetype)init;
- (void)viewDidLoad;
@end
