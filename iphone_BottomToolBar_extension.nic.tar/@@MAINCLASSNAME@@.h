#import "Headers/BTBCustomModule.h"

@interface @@MAINCLASSNAME@@ : BTBCustomModuleViewController

@end
